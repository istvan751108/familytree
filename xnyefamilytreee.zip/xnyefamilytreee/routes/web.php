<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FamilyMemberController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\RelationshipController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// For FamilyMemberController
Route::get('/familymember/all', [FamilyMemberController::class, 'AllMember'])->name('all.familymember');
Route::get('/familymember/create', [FamilyMemberController::class, 'CreateMember'])->name('create.familymember');
Route::post('/familymember/add', [FamilyMemberController::class, 'AddMember'])->name('add.familymember');
Route::get('/familymember/edit/{id}', [FamilyMemberController::class, 'Edit']);
Route::post('/familymember/update/{id}', [FamilyMemberController::class, 'Update']);
Route::get('/softdelete/familymember/{id}', [FamilyMemberController::class, 'SoftDelete']);
Route::get('/restore/familymember/{id}', [FamilyMemberController::class, 'Restore']);
Route::get('/pdelete/familymember/{id}', [FamilyMemberController::class, 'Pdelete']);
Route::get('/familymember/relation/{id}', [FamilyMemberController::class, 'Relation']);

// For GalleryController
Route::get('/gallery/all', [GalleryController::class, 'AllGellery'])->name('all.gallery');
Route::get('/gallery/add', [GalleryController::class, 'AddGellery'])->name('add.gallery');
Route::post('/gallery/store', [GalleryController::class, 'StoreGellery'])->name('store.gallery');
Route::get('/gallery/show/{id}', [GalleryController::class, 'Show']);
Route::get('/gallery/carousel/{id}', [GalleryController::class, 'Carousel']);

// For PhotoController
Route::get('/photo/create/{id}', [PhotoController::class, 'AddPhoto']);
Route::post('/photo/store', [PhotoController::class, 'StorePhoto'])->name('store.photo');

// For RelationshipController
Route::get('/relationship/add_parent/{id}', [RelationshipController::class, 'AddParent']);
Route::post('/relationship/store_parent', [RelationshipController::class, 'StoreParent'])->name('store_parent.relationship');
Route::get('/relationship/add_children/{id}', [RelationshipController::class, 'AddChildren']);
Route::post('/relationship/store_child', [RelationshipController::class, 'StoreChild'])->name('store_child.relationship');
Route::get('/relationship/show', [RelationshipController::class, 'Show'])->name('show.relationship');
Route::post('/relationship/create_family', [RelationshipController::class, 'CreateFamily'])->name('create_family.relationship');

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');