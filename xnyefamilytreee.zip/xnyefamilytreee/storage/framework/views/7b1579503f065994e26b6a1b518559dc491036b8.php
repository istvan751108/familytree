<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="row g-3">
            <div class="col-md-3">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Családfa
                </h2>
            </div>
            <div class="col-md-7">
                <form action="<?php echo e(route('create_family.relationship')); ?>" method="post" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <div class="col-auto">
                        <select class="form-select" aria-label="Disabled select example" name="selected">
                            <?php if($my_own): ?>
                            <?php $__currentLoopData = $my_own; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $own): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($own->id); ?>"><?php echo e($own->first_name); ?> <?php echo e($own->last_name); ?> <?php echo e($own->birth_date); ?> <?php echo e($own->birth_place); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-primary" type="submit">Családfa készítés</button>
                    </div>

                </form>

            </div>

        </div>


     <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <div class="col d-flex justify-content-center">
        <?php if(isset($members)): ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card mb-3" style="max-width: 250px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo e(asset($member->member_image)); ?>" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></h6>
                        <p class="card-text"><small class="text-muted"><?php echo e($member->birth_date); ?></small></p>

                    </div>
                </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


    </div>
    <?php if(isset($childrenArray)): ?>
    <?php $__currentLoopData = $childrenArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($children)): ?>
    <div class="col d-flex justify-content-center" style="height: 30px;">
        <div></div>
    </div>
    <div class="col d-flex justify-content-center">
        <hr style="height:4px; width:100px; color:blue; background-color:blue">
    </div>
    <div class="col d-flex justify-content-center" style="height: 30px;">

    </div>

    <div class="col d-flex justify-content-center">
        <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($child)): ?>
        <div class="card mb-3" style="max-width: 250px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo e(asset($child->member_image)); ?>" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($child->first_name); ?> <?php echo e($child->last_name); ?></h6>
                        <p class="card-text"><small class="text-muted"><?php echo e($child->birth_date); ?></small></p>

                    </div>
                </div>
            </div>
        </div>


        <?php else: ?>
        <div class="position-relative p-1 mx-3" style="width: 6rem;">

        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\nyefamilytreee\resources\views/admin/relationship/show_relationship.blade.php ENDPATH**/ ?>