<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="col-md-12">
        <div class="card">


            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.nav-link','data' => ['href' => ''.e(route('create.familymember')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('create.familymember')).'']); ?>
                <h5> Adj hozzá új családtagot.</h5>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Sorsz.</th>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Kép</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Lakóhely</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($members->firstItem()+$loop->index); ?> </th>
                        <td> <?php echo e($member->user->name); ?> </td>
                        <td> <?php echo e($member->first_name); ?> </td>
                        <td> <?php echo e($member->last_name); ?> </td>
                        <td> <img src="<?php echo e(asset($member->member_image)); ?>" style="height:40px;"> </td>
                        <td> <?php echo e($member->gender); ?> </td>
                        <td> <?php echo e($member->birth_date); ?> </td>
                        <td> <?php echo e($member->birth_place); ?> </td>
                        <td> <?php echo e($member->death_date); ?> </td>
                        <td> <?php echo e($member->death_place); ?> </td>
                        <td>
                            <?php if($member->created_at == NULL): ?>
                            <span class="text-danger"> No Date Set</span>
                            <?php else: ?>
                            <?php echo e(Carbon\Carbon::parse($member->created_at)->diffForHumans()); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('familymember/edit/'.$member->id)); ?>" class="btn btn-info">Mód.</a>
                            <button class="btn btn-outline-success dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Kapcsolatok</button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo e(url('relationship/add_parent/'.$member->id)); ?>">Szülő hozáadása</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('relationship/add_children/'.$member->id)); ?>">Gyerek hozzáadása</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>

                            </ul>
                            <a href="<?php echo e(url('softdelete/familymember/'.$member->id)); ?>" class="btn btn-danger">Töröl</a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($members->links()); ?>


        </div>


        
    </div>


    <!-- Trash Part -->


    <div class="col-md-12">
        <div class="card">

            <div class="card-header"> Törlendő Családtagok </div>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Sorsz.</th>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Kép</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Lakóhely</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $trachCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($members->firstItem()+$loop->index); ?> </th>
                        <td> <?php echo e($member->user->name); ?> </td>
                        <td> <?php echo e($member->first_name); ?> </td>
                        <td> <?php echo e($member->last_name); ?> </td>
                        <td> <img src="<?php echo e(asset($member->member_image)); ?>" style="height:40px;"> </td>
                        <td> <?php echo e($member->gender); ?> </td>
                        <td> <?php echo e($member->birth_date); ?> </td>
                        <td> <?php echo e($member->birth_place); ?> </td>
                        <td> <?php echo e($member->death_date); ?> </td>
                        <td> <?php echo e($member->death_place); ?> </td>
                        <td>
                            <?php if($member->created_at == NULL): ?>
                            <span class="text-danger"> No Date Set</span>
                            <?php else: ?>
                            <?php echo e(Carbon\Carbon::parse($member->created_at)->diffForHumans()); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('restore/familymember/'.$member->id)); ?>" class="btn btn-info">Vissza</a>
                            <a href="<?php echo e(url('pdelete/familymember/'.$member->id)); ?>" class="btn btn-danger">Töröl</a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($trachCat->links()); ?>


        </div>
    </div>



    <!-- End Trush -->
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\nyefamilytreee\resources\views/admin/familymember/index.blade.php ENDPATH**/ ?>