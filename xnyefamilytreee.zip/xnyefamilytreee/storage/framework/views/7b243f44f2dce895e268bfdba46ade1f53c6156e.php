<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="row">

            <h3 class="mr-3"> <?php echo e($gallery->galery_name); ?></h3>
            <h4><?php echo e($gallery->description); ?></h4>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="container">
        <div class="row">
            <?php if($photos): ?>

            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="carousel-item <?php echo e($loop->iteration == 1 ? 'active' : ''); ?>">
                        <img class="d-block w-100" src="<?php echo e(asset($photo->image)); ?>" alt="First slide">
                        <div class="carousel-caption d-none d-md-block text-white">
                            <h3 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);"><?php echo e($photo->title); ?></h3>
                            <h4 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);"><?php echo e($photo->description); ?></h4>
                            <h5 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);"><?php echo e($photo->location); ?></h5>
                        </div>
                    </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            <?php endif; ?>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\xnyefamilytreee\resources\views/admin/photo/carousel.blade.php ENDPATH**/ ?>