<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            Új fotó feltöltése

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="card col-md-4">
                <div class="card-header"> Kép hozzáadása </div>
                <div class="card-body">
                    <form action="<?php echo e(route('store.photo')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group ">
                            <div>
                                <label for="validationDefault01">A kép címe</label>
                                <input type="text" name="title" class="form-control" id="validationDefault01" required>
                            </div>
                            <div>
                                <label for="validationDefault02">A kép leírása</label>
                                <input type="text" name="description" class="form-control" id="validationDefault02">
                            </div>
                            <div>
                                <label for="validationDefault03">Készítés helye</label>
                                <input type="text" name="location" class="form-control" id="validationDefault03">
                            </div>
                            <div>
                                <label for="validationDefault04">Kép kiválasztása</label>
                                <input type="file" name="image" class="form-control" id="validationDefault04" required>
                            </div>
                            <input type="hidden" name="gallery_id" value="<?php echo e($gallery_id); ?>" class="form-control" id="validationDefault03">
                        </div>

                        <button class="btn btn-primary" type="submit">Feltöltés</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\xnyefamilytreee\resources\views/admin/photo/create.blade.php ENDPATH**/ ?>