<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            Családtag hozzáadása<b> </b>


        </h2>
     <?php $__env->endSlot(); ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('success')); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="card">
            <div class="card-header"> Családtag hozzáadása </div>
            <div class="card-body">
                <form action="<?php echo e(route('add.familymember')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 row">
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault01">Vezetéknév</label>
                            <input type="text" name="first_name" class="form-control" id="validationDefault01" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault02">Keresztnév</label>
                            <input type="text" name="last_name" class="form-control" id="validationDefault02" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault03">Születési dátum</label>
                            <input type="text" name="birth_date" class="form-control" id="validationDefault03" required>
                            <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault04">Születési hely</label>
                            <input type="text" name="birth_place" class="form-control" id="validationDefault04" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault04">Halál dátum</label>
                            <input type="text" name="death_date" class="form-control" id="validationDefault05">
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault06">Lakóhely</label>
                            <input type="text" name="death_place" class="form-control" id="validationDefault06">
                        </div>
                        <div class="col-md-4 mb-2">
                            <label for="validationDefault07">Kép kiválasztása</label>
                            <input type="file" name="member_image" class="form-control" id="validationDefault04">
                        </div>
                        <?php $__errorArgs = ['member_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="col-md-2 mb-2">
                            <label for="validationDefault06">Neme</label>
                            <select id="validationDefault06" name="gender" class="form-select" type="text">
                                <option selected>Férfi</option>
                                <option>Nő</option>
                            </select>
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Új családtag rögzítése</button>
                </form>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\nyefamilytreee\resources\views/admin/familymember/add.blade.php ENDPATH**/ ?>