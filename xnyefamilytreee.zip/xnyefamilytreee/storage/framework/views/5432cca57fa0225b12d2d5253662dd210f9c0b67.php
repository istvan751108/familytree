<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="col-md-12">
        <div class="card">


            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>


            <div class="card-header row ">
                <div class="row">
                    <div>
                        <td> <?php echo e($member->death_place); ?> </td>
                        <?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?> <?php echo e($member->gender); ?> <?php echo e($member->birth_date); ?> <?php echo e($member->birth_place); ?> <?php echo e($member->death_date); ?> <?php echo e($member->death_place); ?> gyerekeinek kiválasztása.
                    </div>
                    <div>

                    </div>
                </div>
            </div>


            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $not_parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($parent->user->name); ?> </td>
                        <td> <?php echo e($parent->first_name); ?> </td>
                        <td> <?php echo e($parent->last_name); ?> </td>
                        <td> <?php echo e($parent->gender); ?> </td>
                        <td> <?php echo e($parent->birth_date); ?> </td>
                        <td> <?php echo e($parent->birth_place); ?> </td>
                        <td> <?php echo e($parent->death_date); ?> </td>
                        <td> <?php echo e($parent->death_place); ?> </td>
                        <td>
                            <?php if($parent->created_at == NULL): ?>
                            <span class="text-danger"> No Date Set</span>
                            <?php else: ?>
                            <?php echo e(Carbon\Carbon::parse($parent->created_at)->diffForHumans()); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <form action="<?php echo e(route('store_child.relationship')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-1">
                                        <input type="hidden" value="<?php echo e($member->id); ?>" name="parent_id" class="form-control" id="validationDefault01" required>
                                    </div>
                                    <div class="col-md-1">
                                        <input type="hidden" value="<?php echo e($parent->id); ?>" name="child_id" class="form-control" id="validationDefault01" required>
                                    </div>
                                    <div class="col-auto">
                                        <button class="btn btn-primary" type="submit">Gyerek rögzítése</button>
                                    </div>
                            </form>

                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>


        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\xnyefamilytreee\resources\views/admin/relationship/add_children.blade.php ENDPATH**/ ?>