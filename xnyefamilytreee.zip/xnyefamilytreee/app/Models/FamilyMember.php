<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FamilyMember extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $fillable = [
        'id',
        'user_id',
        'first_name',
        'last_name',
        'member_image',
        'gender',
        'birth_date',
        'birth_place',
        'death_date',
        'death_place',
    ];

    public function user()
    {
        return $this->hasOne(User::class, 'id', 'user_id');
    }
}