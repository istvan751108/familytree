<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FamilyMember;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\DataConverter;
use Laudis\Neo4j\Authentication\Authenticate;
use Laudis\Neo4j\ClientBuilder;

require '..\vendor\autoload.php';
class FamilyMemberController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function AllMember()
    {
        $members = FamilyMember::where('user_id', Auth::user()->id)->latest()->paginate(12);

        $trachCat = FamilyMember::onlyTrashed()->latest()->paginate(3);

        return view('admin.familymember.index', compact('members', 'trachCat'));
    }

    public function CreateMember()
    {
        return view('admin.familymember.add');
    }

    public function Neo4jConnect()
    {
        $url = 'bolt://localhost:7689?database=neo4j';
        $auth = Authenticate::basic('neo4j', 'password');
        $client = ClientBuilder::create()->withDriver('neo4j', $url, $auth)->build();

        return ($client);
    }

    public function AddMember(Request $request)
    {
        $client = $this->Neo4jConnect();

        $first_name = $request->first_name;
        $last_name = $request->last_name;
        $name_full = $first_name . " " . $last_name;
        $gender = $request->gender;
        $b_date = $request->birth_date;
        $b_place = $request->birth_place;
        $d_date = $request->death_date;
        $d_place = $request->death_place;

        $validatedData = $request->validate(
            [
                'member_image' => 'mimes:jpg,jpeg,png',
                'birth_date' => 'required|date|before_or_equal:today',
            ],
            [
                'member_image' => 'Csak jpg,jpeg,png formátum engedélyezett',
                'birth_date' => 'A születési dátum nem lehet jövőbeli!',
            ]
        );

        $brand_image = $request->file('member_image');

        if ($brand_image) {
            $name_gen = hexdec(uniqid());
            $img_ext = strtolower($brand_image->getClientOriginalExtension());
            $img_name = $name_gen . '.' . $img_ext;
            $up_location = 'image/members/';
            $last_img = $up_location . $img_name;
            $brand_image->move($up_location, $img_name);

            FamilyMember::insert([
                'user_id' => Auth::user()->id,
                'created_at' => Carbon::now(),
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'member_image' => $last_img,
                'gender' => $request->gender,
                'birth_date' => $request->birth_date,
                'birth_place' => $request->birth_place,
                'death_date' => $request->death_date,
                'death_place' => $request->death_place
            ]);
        } else {
            FamilyMember::insert([
                'user_id' => Auth::user()->id,
                'created_at' => Carbon::now(),
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'gender' => $request->gender,
                'birth_date' => $request->birth_date,
                'birth_place' => $request->birth_place,
                'death_date' => $request->death_date,
                'death_place' => $request->death_place
            ]);
        }
        $client->run('MERGE (p:Person {name:"' . $name_full . '", gender:"' . $gender . '",birth_date:"' . $b_date . '",birth_place:"' . $b_place . '",death_date:"' . $d_date . '",death_place:"' . $d_place . '"})');
        return Redirect()->back()->with('success', 'Családtag sikeresen hozzáadva.');
    }

    public function Edit($id)
    {
        $members = FamilyMember::find($id);
        return view('admin.familymember.edit', compact('members'));
    }

    public function Update(Request $request, $id)
    {
        $members = FamilyMember::find($id);
        $member_name = $members->first_name . " " . $members->last_name;
        $member_birthDate = $members->birth_date;
        $client = $this->Neo4jConnect();

        $first_name = $request->first_name;
        $last_name = $request->last_name;
        $name_full = $first_name . " " . $last_name;
        $gender = $request->gender;
        $b_date = $request->birth_date;
        $b_place = $request->birth_place;
        $d_date = $request->death_date;
        $d_place = $request->death_place;

        $validatedData = $request->validate(
            [
                'member_image' => 'mimes:jpg,jpeg,png',
                'birth_date' => 'required|date|before_or_equal:today',
            ],
            [
                'member_image' => 'Csak jpg,jpeg,png formátum engedélyezett',
                'birth_date' => 'A születési dátum nem lehet jövőbeli!',
            ]
        );

        $old_image = $request->old_image;
        $brand_image = $request->file('member_image');
        if ($brand_image) {
            $name_gen = hexdec(uniqid());
            $img_ext = strtolower($brand_image->getClientOriginalExtension());
            $img_name = $name_gen . '.' . $img_ext;
            $up_location = 'image/members/';
            $last_img = $up_location . $img_name;
            $brand_image->move($up_location, $img_name);

            if ($old_image != 'image/members/member.jpg') {
                unlink($old_image);
            }

            $update = FamilyMember::find($id)->update([
                'user_id' => Auth::user()->id,
                'created_at' => Carbon::now(),
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'member_image' => $last_img,
                'gender' => $request->gender,
                'birth_date' => $request->birth_date,
                'birth_place' => $request->birth_place,
                'death_date' => $request->death_date,
                'death_place' => $request->death_place
            ]);
        } else {
            $update = FamilyMember::find($id)->update([
                'user_id' => Auth::user()->id,
                'created_at' => Carbon::now(),
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'gender' => $request->gender,
                'birth_date' => $request->birth_date,
                'birth_place' => $request->birth_place,
                'death_date' => $request->death_date,
                'death_place' => $request->death_place
            ]);
        }

        $data = $this->Neo4jIDSelector($client, $member_name);

        foreach ($data as $person) {
            $client->run('MATCH(p) WHERE ID(p)= ' . $person["id"] . ' AND p.birth_date = "' . $member_birthDate . '"
                SET p.name="' . $name_full . '", p.birth_date="' . $b_date . '",p.birth_place="' . $b_place . '",p.death_date="' . $d_date . '",p.death_place="' . $d_place . '",p.gender="' . $gender . '"
                RETURN p');
        }
        return Redirect()->route('all.familymember')->with('success', 'Családtag adatai sikeresen megváltoztatva.');

    }

    public function SoftDelete($id)
    {
        $delete = FamilyMember::find($id)->delete();
        return Redirect()->back()->with('success', 'Családtag törlése még visszavonható');
    }

    public function Restore($id)
    {
        $delete = FamilyMember::withTrashed()->find($id)->restore();
        return Redirect()->back()->with('success', 'Családtag visszaállítás kész');
    }

    public function Pdelete($id)
    {
        $image = FamilyMember::withTrashed()->find($id);
        $old_image = $image->member_image;
        if ($old_image != 'image/members/member.jpg') {
            unlink($old_image);
        }

        $member_name = $image->first_name . " " . $image->last_name;
        $member_birthDate = $image->birth_date;

        $client = $this->Neo4jConnect();

        $data = $this->Neo4jIDSelector($client, $member_name);

        foreach ($data as $person) {
            $client->run('MATCH(p) WHERE ID(p)= ' . $person["id"] . ' AND p.birth_date = "' . $member_birthDate . '"
                Detach DELETE p');
        }

        $delete = FamilyMember::onlyTrashed()->find($id)->forceDelete();
        return Redirect()->back()->with('success', 'Családtag véglegesen törölve');
    }

    public function Relation()
    {
        return view('admin.familymember.relation');
    }

    public function Neo4jIDSelector($client, $member_name)
    {
        $query = 'MATCH (n:Person {name:"' . $member_name . '"}) RETURN id(n), n.name, n.gender, n.birth_date, n.birth_place, n.death_date, n.death_place';
        $result = $client->run($query);

        // iterate over the result and store data in an array
        $data = [];
        foreach ($result->getResults() as $record) {
            $data[] = [
                'id' => $record->get('id(n)'),
                'name' => $record->get('n.name'),
                'gender' => $record->get('n.gender'),
                'birth_date' => $record->get('n.birth_date'),
                'birth_place' => $record->get('n.birth_place'),
                'death_date' => $record->get('n.death_date'),
                'death_place' => $record->get('n.death_place'),
            ];
        }
        return $data;
    }
}
