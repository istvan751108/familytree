<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Gallery;
use App\Models\Photo;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class GalleryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function AllGellery()
    {
        $galleries = Gallery::latest()->paginate(9);

        return view('admin.gallery.index', compact('galleries'));
    }

    public function AddGellery()
    {

        return view('admin.gallery.create');
    }

    public function StoreGellery(Request $request)
    {
        $validatedData = $request->validate(
            [
                'galery_name' => 'required|unique:galleries|min:4',
                'brand_image' => 'required|mimes:jpg,jpeg,png',

            ],
            [
                'galery_name.required' => 'Galéria név kötelező',
                'galery_name.min' => 'A név hossza minimum 4 karakter kell legyen',
            ]
        );

        $brand_image = $request->file('brand_image');

        $name_gen = hexdec(uniqid());
        $img_ext = strtolower($brand_image->getClientOriginalExtension());
        $img_name = $name_gen . '.' . $img_ext;
        $up_location = 'image/galleries/';
        $last_img = $up_location . $img_name;
        $brand_image->move($up_location, $img_name);


        Gallery::insert([
            'galery_name' => $request->galery_name,
            'description' => $request->description,
            'cover_image' => $last_img,
            'owner_id' => Auth::user()->id,
            'created_at' => Carbon::now()
        ]);

        return Redirect()->back()->with('success', 'Galéria sikeresen hozzáadva.');
    }

    public function Show($id)
    {
        $gallery = Gallery::find($id);
        $photos = Photo::where('gallery_id', $id)->get();

        return view('admin.gallery.show', compact('gallery', 'photos'));
    }

    public function Carousel($id)
    {
        $gallery = Gallery::find($id);
        $photos = Photo::where('gallery_id', $id)->get();

        return view('admin.photo.carousel', compact('gallery', 'photos'));
    }
}