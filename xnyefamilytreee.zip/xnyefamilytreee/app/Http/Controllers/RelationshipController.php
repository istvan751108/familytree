<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FamilyMember;
use App\Models\Relationship;
use App\Rules\MoreThanTwoParents;
use App\Http\Controllers\FamilyMemberController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Laudis\Neo4j\Authentication\Authenticate;
use Laudis\Neo4j\ClientBuilder;

require '..\vendor\autoload.php';
class RelationshipController extends Controller
{
    public function AddParent($id)
    {
        $member = FamilyMember::find($id);
        $parents = Relationship::where('parent_id', $id)->pluck('child_id');
        $children = Relationship::where('child_id', $id)->pluck('parent_id');
        $not_parents = FamilyMember::whereNot('id', $id)->whereNotIn('id', $parents)->whereNotIn('id', $children)->get();

        return view('admin.relationship.add_parent', compact('member', 'not_parents'));
    }

    public function StoreParent(Request $request)
    {
        $validatedData = $request->validate(
            [
                'child_id' => [new MoreThanTwoParents],
            ]

        );
        $this->ParentContactMaker($request);

        Relationship::insert([
            'parent_id' => $request->parent_id,
            'child_id' => $request->child_id,
            'owner_id' => Auth::user()->id,
            'created_at' => Carbon::now()
        ]);

        return Redirect()->back()->with('success', 'Szülő sikeresen hozzáadva.');
    }

    public function AddChildren($id)
    {
        $member = FamilyMember::find($id);
        $parents = Relationship::where('parent_id', $id)->pluck('child_id');
        $children = Relationship::where('child_id', $id)->pluck('parent_id');
        $not_parents = FamilyMember::whereNot('id', $id)->whereNotIn('id', $parents)->whereNotIn('id', $children)->get();

        return view('admin.relationship.add_children', compact('member', 'not_parents'));
    }

    public function StoreChild(Request $request)
    {
        $this->ParentContactMaker($request);
        Relationship::insert([
            'parent_id' => $request->parent_id,
            'child_id' => $request->child_id,
            'owner_id' => Auth::user()->id,
            'created_at' => Carbon::now()
        ]);

        return Redirect()->back()->with('success', 'Gyerek sikeresen hozzáadva.');
    }

    public function ParentContactMaker($request)
    {
        $parent_member = FamilyMember::find($request->parent_id);
        $child_member = FamilyMember::find($request->child_id);
        $parent_member_name = $parent_member->first_name . " " . $parent_member->last_name;
        $child_member_name = $child_member->first_name . " " . $child_member->last_name;
        $parent_member_birth_date = $parent_member->birth_date;
        $child_member_birth_date = $child_member->birth_date;

        $family = new FamilyMemberController();
        $client = $family->Neo4jConnect();

        $neo4jParent = $family->Neo4jIDSelector($client, $parent_member_name);
        foreach ($neo4jParent as $person) {
            if ($person["birth_date"] == $parent_member_birth_date) {
                $parentMemberId = $person["id"]; // Store the found ID in a variable
                break; // Exit the loop once the ID is found
            }
        }

        $neo4jChild = $family->Neo4jIDSelector($client, $child_member_name);
        foreach ($neo4jChild as $person) {
            if ($person["birth_date"] == $child_member_birth_date) {
                $childMemberId = $person["id"]; // Store the found ID in a variable
                break; // Exit the loop once the ID is found
            }
        }

        $client->run('MATCH(p1) WHERE ID(p1)= ' . $childMemberId . ' MATCH(p2) WHERE ID(p2)= ' . $parentMemberId . '
                             MERGE (p1)-[:SZÜLŐ]->(p2) RETURN p1,p2');
    }

    public function Show()
    {
        $my_own = FamilyMember::orderBy('first_name')->orderBy('last_name')->get();
        $member = null;
        $children = null;
        return view('admin.relationship.show_relationship', compact('my_own', 'member', 'children'));
    }

    public function CreateFamily(Request $request)
    {
        $childrenArray = array();
        $child3_ids = array();
        $child2_ids = array();
        $child5_ids = array();
        $my_own = FamilyMember::orderBy('first_name')->orderBy('last_name')->get();
        $members_ids[0] = $request->selected;
        $child_ids = $this->SearchChildren($request->selected);
        $parents = Relationship::whereIn('child_id', $child_ids)->pluck('parent_id');
        foreach ($parents as $parent) {
            foreach ($members_ids as $member) {
                if (!in_array($parent, $members_ids)) {
                    array_push($members_ids, $parent);
                    break;
                }
            }
        }
        $members = FamilyMember::whereIn('id', $members_ids)->get();

        $children = $this->CreateChildren($child_ids);
        array_push($childrenArray, $children);

        if (count($child_ids) > 0) {
            foreach ($child_ids as $child_id) {
                $child2_ids = $this->SearchChildren($child_id);
                foreach ($child2_ids as $child2_id) {
                    array_push($child3_ids, $child2_id);
                }
            }
            array_push($childrenArray, $this->CreateChildren($child3_ids));
        }

        if (count($child2_ids) > 0) {
            foreach ($child2_ids as $child2_id) {
                $child4_ids = $this->SearchChildren($child2_id);
                foreach ($child4_ids as $child4_id) {
                    array_push($child5_ids, $child4_id);
                }
            }
            array_push($childrenArray, $this->CreateChildren($child5_ids));
        }

        return view('admin.relationship.show_relationship', compact('my_own', 'members', 'childrenArray'));
    }

    public function MyOwn()
    {
        return FamilyMember::where('user_id', Auth::user()->id)->get();
    }

    public function SearchChildren($child_id)
    {
        return Relationship::where('parent_id', $child_id)->pluck('child_id');
    }

    public function SearchParents($child_id)
    {
        return Relationship::where('child_id', $child_id)->pluck('parent_id');
    }

    public function CreateChildren($child_ids)
    {
        $children = array();
        $parents2S = array();

        foreach ($child_ids as $child_id) {
            $child2_ids = $this->SearchChildren($child_id);
            if (count($child2_ids) == 0) {
                $child = FamilyMember::find($child_id);
                array_push($children, $child);
                $child = null;
                array_push($children, $child);
            }
            foreach ($child2_ids as $child2_id) {
                $parents2 = $this->SearchParents($child2_id)->toArray();
                if (!isset($parents2S)) {
                    array_push($parents2S, $parents2);
                } else {
                    if (in_array($parents2, $parents2S)) {
                        break;
                    } else {
                        array_push($parents2S, $parents2);
                    }
                }
                foreach ($parents2 as $parent2) {
                    $child = FamilyMember::find($parent2);
                    array_push($children, $child);
                }
                $child = null;
                array_push($children, $child);
            }
        }
        return $children;
    }
}