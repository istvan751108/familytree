<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Photo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Carbon;

class PhotoController extends Controller
{
    public function AddPhoto($gallery_id)
    {

        return view('admin.photo.create', compact('gallery_id'));
    }

    public function StorePhoto(Request $request)
    {
        $validatedData = $request->validate(
            [
                'image' => 'required|mimes:jpg,jpeg,png',

            ]
        );

        $brand_image = $request->file('image');

        $name_gen = hexdec(uniqid());
        $img_ext = strtolower($brand_image->getClientOriginalExtension());
        $img_name = $name_gen . '.' . $img_ext;
        $up_location = 'image/photos/' . $request->gallery_id . '/';
        $last_img = $up_location . $img_name;
        $brand_image->move($up_location, $img_name);


        Photo::insert([
            'title' => $request->title,
            'gallery_id' => $request->gallery_id,
            'description' => $request->description,
            'location' => $request->location,
            'image' => $last_img,
            'owner_id' => Auth::user()->id,
            'created_at' => Carbon::now()
        ]);

        return Redirect()->back()->with('success', 'Kép sikeresen feltöltve.');
    }


}