<x-app-layout>
    <x-slot name="header">
        <div class="row">

            <h3 class="mr-3"> {{ $gallery->galery_name }}</h3>
            <h4>{{ $gallery->description }}</h4>
        </div>
    </x-slot>

    <div class="container">
        <div class="row">
            @if($photos)

            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    @foreach($photos as $photo)

                    <div class="carousel-item {{$loop->iteration == 1 ? 'active' : ''}}">
                        <img class="d-block w-100" src="{{ asset($photo->image) }}" alt="First slide">
                        <div class="carousel-caption d-none d-md-block text-white">
                            <h3 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);">{{ $photo->title }}</h3>
                            <h4 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);">{{ $photo->description }}</h4>
                            <h5 style="color: var(--bs-white);text-shadow: 0px 0px 6px var(--bs-dark);">{{ $photo->location }}</h5>
                        </div>
                    </div>


                    @endforeach
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            @endif

        </div>
    </div>

</x-app-layout>