<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            Családtag hozzáadása<b> </b>


        </h2>
    </x-slot>
    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session('success') }}</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <div class="container">
        <div class="card">
            <div class="card-header"> Családtag hozzáadása </div>
            <div class="card-body">
                <form action="{{ route('add.familymember') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3 row">
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault01">Vezetéknév</label>
                            <input type="text" name="first_name" class="form-control" id="validationDefault01" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault02">Keresztnév</label>
                            <input type="text" name="last_name" class="form-control" id="validationDefault02" required>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault03">Születési dátum</label>
                            <input type="text" name="birth_date" class="form-control" id="validationDefault03" required>
                            @error('birth_date')
                            <span class="text-danger"> {{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault04">Születési hely</label>
                            <input type="text" name="birth_place" class="form-control" id="validationDefault04" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault04">Halál dátum</label>
                            <input type="text" name="death_date" class="form-control" id="validationDefault05">
                        </div>
                        <div class="col-md-3 mb-2">
                            <label for="validationDefault06">Halál helye</label>
                            <input type="text" name="death_place" class="form-control" id="validationDefault06">
                        </div>
                        <div class="col-md-4 mb-2">
                            <label for="validationDefault07">Kép kiválasztása</label>
                            <input type="file" name="member_image" class="form-control" id="validationDefault04">
                        </div>
                        @error('member_image')
                        <span class="text-danger"> {{ $message }}</span>
                        @enderror
                        <div class="col-md-2 mb-2">
                            <label for="validationDefault06">Neme</label>
                            <select id="validationDefault06" name="gender" class="form-select" type="text">
                                <option selected>Férfi</option>
                                <option>Nő</option>
                            </select>
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Új családtag rögzítése</button>
                </form>
            </div>
        </div>
    </div>

</x-app-layout>