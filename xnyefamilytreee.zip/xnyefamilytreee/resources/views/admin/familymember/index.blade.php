<x-app-layout>


    <div class="col-md-12">
        <div class="card">


            @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>{{ session('success') }}</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            @endif

            <x-jet-nav-link href="{{ route('create.familymember') }}">
                <h5> Adj hozzá új családtagot.</h5>
            </x-jet-nav-link>


            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Sorsz.</th>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Kép</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Születési hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Halál helye</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($members as $member)
                    <tr>
                        <th scope="row"> {{ $members->firstItem()+$loop->index  }} </th>
                        <td> {{ $member->user->name }} </td>
                        <td> {{ $member->first_name }} </td>
                        <td> {{ $member->last_name }} </td>
                        <td> <img src="{{ asset($member->member_image) }}" style="height:40px;"> </td>
                        <td> {{ $member->gender }} </td>
                        <td> {{ $member->birth_date }} </td>
                        <td> {{ $member->birth_place }} </td>
                        <td> {{ $member->death_date }} </td>
                        <td> {{ $member->death_place}} </td>
                        <td>
                            @if($member->created_at == NULL)
                            <span class="text-danger"> No Date Set</span>
                            @else
                            {{ Carbon\Carbon::parse($member->created_at)->diffForHumans() }}
                            @endif
                        </td>
                        <td>
                            <a href="{{ url('familymember/edit/'.$member->id) }}" class="btn btn-info">Mód.</a>
                            <button class="btn btn-outline-success dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Kapcsolatok</button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="{{ url('relationship/add_parent/'.$member->id) }}">Szülő hozáadása</a></li>
                                <li><a class="dropdown-item" href="{{ url('relationship/add_children/'.$member->id) }}">Gyerek hozzáadása</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>

                            </ul>
                            <a href="{{ url('softdelete/familymember/'.$member->id) }}" class="btn btn-danger">Töröl</a>
                        </td>

                    </tr>
                    @endforeach

                </tbody>
            </table>
            {{ $members->links() }}

        </div>



    </div>


    <!-- Trash Part -->


    <div class="col-md-12">
        <div class="card">

            <div class="card-header"> Törlendő Családtagok </div>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Sorsz.</th>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Kép</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Lakóhely</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($trachCat as $member)
                    <tr>
                        <th scope="row"> {{ $members->firstItem()+$loop->index  }} </th>
                        <td> {{ $member->user->name }} </td>
                        <td> {{ $member->first_name }} </td>
                        <td> {{ $member->last_name }} </td>
                        <td> <img src="{{ asset($member->member_image) }}" style="height:40px;"> </td>
                        <td> {{ $member->gender }} </td>
                        <td> {{ $member->birth_date }} </td>
                        <td> {{ $member->birth_place }} </td>
                        <td> {{ $member->death_date }} </td>
                        <td> {{ $member->death_place}} </td>
                        <td>
                            @if($member->created_at == NULL)
                            <span class="text-danger"> No Date Set</span>
                            @else
                            {{ Carbon\Carbon::parse($member->created_at)->diffForHumans() }}
                            @endif
                        </td>
                        <td>
                            <a href="{{ url('restore/familymember/'.$member->id) }}" class="btn btn-info">Vissza</a>
                            <a href="{{ url('pdelete/familymember/'.$member->id) }}" class="btn btn-danger">Töröl</a>
                        </td>

                    </tr>
                    @endforeach

                </tbody>
            </table>
            {{ $trachCat->links() }}

        </div>
    </div>



    <!-- End Trush -->
    </div>

</x-app-layout>
