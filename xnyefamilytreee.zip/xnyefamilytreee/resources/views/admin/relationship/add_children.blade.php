<x-app-layout>


    <div class="col-md-12">
        <div class="card">


            @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>{{ session('success') }}</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            @endif


            <div class="card-header row ">
                <div class="row">
                    <div>
                        <td> {{ $member->death_place}} </td>
                        {{ $member->first_name }} {{ $member->last_name }} {{ $member->gender }} {{ $member->birth_date }} {{ $member->birth_place }} {{ $member->death_date }} {{ $member->death_place}} gyerekeinek kiválasztása.
                    </div>
                    <div>

                    </div>
                </div>
            </div>


            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Létrehozta</th>
                        <th scope="col">Vezetéknév</th>
                        <th scope="col">Keresztnév</th>
                        <th scope="col">Neme</th>
                        <th scope="col">Születési dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Halál dátum</th>
                        <th scope="col">Hely</th>
                        <th scope="col">Létrehozva</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($not_parents as $parent)
                    <tr>
                        <td> {{ $parent->user->name }} </td>
                        <td> {{ $parent->first_name }} </td>
                        <td> {{ $parent->last_name }} </td>
                        <td> {{ $parent->gender }} </td>
                        <td> {{ $parent->birth_date }} </td>
                        <td> {{ $parent->birth_place }} </td>
                        <td> {{ $parent->death_date }} </td>
                        <td> {{ $parent->death_place}} </td>
                        <td>
                            @if($parent->created_at == NULL)
                            <span class="text-danger"> No Date Set</span>
                            @else
                            {{ Carbon\Carbon::parse($parent->created_at)->diffForHumans() }}
                            @endif
                        </td>
                        <td>
                            <form action="{{ route('store_child.relationship') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                    <div class="col-md-1">
                                        <input type="hidden" value="{{ $member->id }}" name="parent_id" class="form-control" id="validationDefault01" required>
                                    </div>
                                    <div class="col-md-1">
                                        <input type="hidden" value="{{ $parent->id }}" name="child_id" class="form-control" id="validationDefault01" required>
                                    </div>
                                    <div class="col-auto">
                                        <button class="btn btn-primary" type="submit">Gyerek rögzítése</button>
                                    </div>
                            </form>

                        </td>

                    </tr>
                    @endforeach

                </tbody>
            </table>


        </div>

</x-app-layout>