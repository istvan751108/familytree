<x-app-layout>
    <x-slot name="header">
        <div class="row g-3">
            <div class="col-md-3">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Családfa
                </h2>
            </div>
            <div class="col-md-7">
                <form action="{{route('create_family.relationship')}}" method="post" class="row g-3">
                    @csrf
                    <div class="col-auto">
                        <select class="form-select" aria-label="Disabled select example" name="selected">
                            @if ($my_own)
                            @foreach($my_own as $own)
                            <option value="{{ $own->id }}">{{ $own->first_name }} {{ $own->last_name }} {{ $own->birth_date }} {{ $own->birth_place }}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-primary" type="submit">Családfa készítés</button>
                    </div>

                </form>

            </div>

        </div>


    </x-slot>

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session('success') }}</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <div class="row">
    <div class="col-sm-6">
    <div class="col d-flex justify-content-center">
        @if (isset($members))
        @foreach($members as $member)
        <div class="card mb-3" style="max-width: 250px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="{{ asset($member->member_image) }}" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h6 class="card-title">{{ $member->first_name }} {{ $member->last_name }}</h6>
                        <p class="card-text"><small class="text-muted">{{ $member->birth_date }}</small></p>
                    </div>
                </div>
             </div>
        </div>
        @endforeach
        @endif

    </div>

    @if (isset($childrenArray))
    @foreach($childrenArray as $children)
    @if (isset($children))
    <div class="col d-flex justify-content-center" style="height: 30px;">
        <div></div>
    </div>
    <div class="col d-flex justify-content-center">
        <hr style="height:4px; width:100px; color:blue; background-color:blue">
    </div>
    <div class="col d-flex justify-content-center" style="height: 30px;">

    </div>

    <div class="col d-flex justify-content-center">

        @foreach($children as $child)
        @if (isset($child))
        <div class="card mb-3" style="max-width: 250px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="{{ asset($child->member_image) }}" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h6 class="card-title">{{ $child->first_name }} {{ $child->last_name }}</h6>
                        <p class="card-text"><small class="text-muted">{{ $child->birth_date }}</small></p>

                    </div>
                </div>
            </div>
        </div>


        @else

        @endif
        @endforeach

    </div>

    @endif
    @endforeach
    @endif

</div>
    <div class="col-lg-6">
    <script src="https://cdn.neo4jlabs.com/neovis.js/v1.5.0/neovis.js"></script>

        <body onload="draw()" >
            <div id="viz" style= "width: 98%; height: 700px; border: 1px solid lightgray; font: 22pt arial;"></div>
                <script>
                    function draw() {

                        var config = {
                            container_id: "viz",
                            server_url: "bolt://localhost:7689",
                            server_user: "neo4j",
                            server_password: "password",
                            labels: {
                                Person: {
                                    caption: "name",
                   			        sizeCypher: "MATCH (n) WHERE id(n) = $id MATCH (n)-[r]->() RETURN Count(r) +50 "
                                }
                            },
                            relationships: {
                                "SZÜLŐ": {
                   			        "thickness": "weight",
                                    "caption": true,
                                }
                            },
                            initial_cypher: "match p=()-[]->() return p",
                            arrows: true
                        }

                        var viz = new NeoVis.default(config);
                        viz.render();
                    }
                </script>
            </div>
        </body>
    </div>
</div>
</x-app-layout>
