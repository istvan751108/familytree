<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            Kép galériák<b> </b>
            <x-jet-nav-link href="{{ route('add.gallery') }}">
                <h5> Készíts új képgalériát</h5>
            </x-jet-nav-link>

        </h2>
    </x-slot>

    <div class="container">
        <div class="row">
            @foreach($galleries as $gallery)
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="{{ url('gallery/show/'.$gallery->id) }}">
                        <img src="{{ asset($gallery->cover_image) }}" alt="Nature" style="Height: 250px;">
                        <div class="caption">
                            <h4>{{ $gallery->galery_name }}</h4>
                        </div>
                    </a>
                </div>
            </div>
            @endforeach

        </div>

    </div>
    {{ $galleries->links() }}
</x-app-layout>