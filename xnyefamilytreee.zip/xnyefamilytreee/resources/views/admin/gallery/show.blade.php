<x-app-layout>
    <x-slot name="header">
        <div class="row">

           <h3 class="mr-3"> {{ $gallery->galery_name }}</h3>
            <h4 class="mr-3" > {{ $gallery->description }}</h4>
            <x-jet-nav-link href="{{ url('photo/create/'.$gallery->id) }}">
                <h5> Adj hozzá képeket</h5>
            </x-jet-nav-link>

        </div>
    </x-slot>

    <div class="container">
        <div class="row">
            @if($photos)
            @foreach($photos as $photo)
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="{{ url('gallery/carousel/'.$gallery->id) }}">
                        <img src="{{ asset($photo->image) }}" alt="Nature" style="Height: 250px;">
                        <div class="caption">
                            <h4>{{ $photo->title }}</h4>
                            <h5>{{ $photo->description }}</h5>
                        </div>
                    </a>
                </div>
            </div>
            @endforeach
            @endif

        </div>
    </div>

</x-app-layout>