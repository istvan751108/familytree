<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            Új képgaléria hozzáadása<b> </b>


        </h2>
    </x-slot>

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session('success') }}</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">

            </div>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header"> A galéria adatai </div>
                    <div class="card-body">

                    <form action="{{ route('store.gallery') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Galéria neve</label>
                                    <input type="text" name="galery_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                                    @error('galery_name')
                                    <span class="text-danger"> {{ $message }}</span>
                                    @enderror

                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Leírás</label>
                                    <input type="text" name="description" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Boritó kép</label>
                                    <input type="file" name="brand_image" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                                    @error('brand_image')
                                    <span class="text-danger"> {{ $message }}</span>
                                    @enderror

                                </div>

                                <button type="submit" class="btn btn-primary">Feltöltés</button>
                            </form>

                    </div>

                </div>
            </div>
        </div>
    </div>



</x-app-layout>