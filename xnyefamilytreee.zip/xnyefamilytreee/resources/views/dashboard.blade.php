<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Felhasználói útmutató:
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                Miután bejelentkeztünk a programba, ez a felhasználói útmutató nyílik meg elsőként.
                A felső navigációs felületen tudunk váltani a különböző területek között:<br>
                • Műszerfal<br>
                • Családtagok<br>
                • Képgaléria<br>
                • Családfakészítés<br>
            </div>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-2">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <x-jet-nav-link href="{{ route('dashboard') }}">
                    <h5>Műszerfal:</h5>
                </x-jet-nav-link>
                <p>Ez a rész, ahol épp most vagyunk. Ha a program használata közben segítségre lenne szükségünk, akkor a navigációs felületen ide kattintva bármikor tájékozódhatunk.</p>

            </div>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-2">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <x-jet-nav-link href="{{ route('all.familymember') }}">
                    <h5>Családtagok:</h5>
                </x-jet-nav-link>
                <img src="{{ asset('image/welcome/familymembers.png') }}" style="height:auto;" class="p-2" />
                <p>Új családtagot a középső Családtag hozzáadása részen keresztül tudunk felvinni az adatbázisba.<br><br>
                    A kép kiválasztásánál, ha nem viszünk fel saját fényképet, akkor a program egy egyszerű piktogramot helyez el az adatbázisban. Az adatok kitöltése után az Új családtag rögzítése gombra kattintva az új családtag adata megjelenik a felső listán. Egy oldalon egyszerre 5 családtag jelenik meg. Lapozni a jobb oldalon lévő számokkal és nyilakkal tudunk. Az Új családtag adatai mindig a legelső helyen jelennek meg. Ha bármelyik családtag adatait módosítani akarjuk, akkor azt a kék színű Mód. gombbal tehetjük meg, illetve a piros színű Töröl gombbal törölhetjük is a kiválasztott családtagot. (Ilyenkor a lap alján megjelennek a törölni kívánt családtagok adatai és itt vagy vissza tudjuk vonni, vagy meg tudjuk erősíteni a törlést.)<br><br>
                    A Kapcsolatok gombra kattintva egy legördülő lista jelenik meg, ahol az adott családtaghoz hozzá tudunk rendelni Gyereket vagy Szülőt.</p>
            </div>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-2">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <x-jet-nav-link href="{{ route('all.gallery') }}">
                    <h5>Képgaléria:</h5>
                </x-jet-nav-link>
                <img src="{{ asset('image/welcome/galeries.png') }}" style="height:auto;" class="p-2" />
                <p>Itt különböző fotók közül tudunk válogatni, illetve saját fotógalériát is elhelyezhetünk az oldal felső részén található Készíts új képgalériát gombra kattintva.</p>
            </div>
        </div>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-2">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <x-jet-nav-link href="{{ route('show.relationship') }}">
                    <h5>Családfakészítés:</h5>
                </x-jet-nav-link>
                <img src="{{ asset('image/welcome/familytree.png') }}" style="height:auto;" class="p-2" />
                <p>A legördülő listából ki tudjuk választani azt a családtagunkat, akinek meg kívánjuk tekinteni a családfáját. Szándékunkat a családtag kiválasztása után a Családfa készítés nyomógombra kattintva tudjuk elindítani.<br><br>
                    A kattintás után a családfa a kiválasztó sáv alatti területen jelenik meg. A kiválasztott családfa mellett az adatbázisba feltöltött összes személy kapcsolati gráfját láthatjuk.</p>
            </div>
        </div>
    </div>
</x-app-layout>
