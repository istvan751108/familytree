# Adatvédelmi irányelvek

„Az általános adatvédelmi rendelet, hivatalosan Az Európai Parlament és a Tanács (EU) 2016/679 rendelete a természetes személyeknek a személyes adatok kezelése tekintetében történő védelméről és az ilyen adatok szabad áramlásáról, valamint a 95/46/EK irányelv hatályon kívül helyezéséről[1] (angolul: General Data Protection Regulation, röviden: GDPR) az Európai Unió rendelete, amely az Európai Gazdasági Térség területén tartózkodó természetes személyek személyes adatait védi és rendelkezik a tagállamok közötti szabad információáramlásról.”
Forrás: Wikipédia

Ezen webalkalmazás használata minden kötöttségtől mentesen ingyenesen megtehető.

A készítő felhívja a leendő Felhasználók figyelmét arra a tényre, hogy e szoftver a Nyíregyházi Egyetem szakdolgozati projektmunkájának  készült. Bár a programozó törekedett arra, hogy az alkalmazás használata a lehető legnagyobb mértékben megfeleljen a szoftvertermékeknél alkalmazandó adatvédelmi jogszabályoknak, de a fent megnevezett okok miatt az alkalmazás készítője semmilyen felelősséget nem vállal a felhasználók személyes adatainak esetleges nyilvánosságra kerüléséért.

(A szoftver által bekért adatok egy közös adatbázisban kerülnek eltárolásra és az alkalmazás jellegénél fogva bármely regisztrált felhasználó részére (a felhasználók személyes regisztrációs adatai kivételével) teljeskörűen hozzáférhetőek.)

A fent részletezett okok miatt felhívom a kedves leendő felhasználók figyelmét arra, hogy az alkalmazást kizárólag saját felelősségük biztos tudatában tegyék meg. 

A termék használatához jó szórakozást kíván: az Nyefamilytree programozója!
