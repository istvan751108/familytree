# Szolgáltatási Feltételek


Köszönjük, hogy meglátogatta ezt a weboldalt! Reméljük, hogy elnyeri tetszését!

Az NYEFamilyTree programozója a Nyíregyházi Egyetem levelezős hallgatója. A Weboldal Szakdolgozati feladatként készült 2023-ban. A weboldal használatára az alábbi feltételek érvényesek.

Elfogadható használat:
Kedve szerint fedezze fel a weboldalt és ahol ez lehetséges, tegyen fel különféle anyagokat és járuljon hozzá a weboldalhoz saját családjának nyilvános adataival és bátran töltse fel a képgalériát kedvenc fotóival. 
Az oldal használata során, kérjük, vegye figyelembe, hogy a weboldal használata és a beküldött fotók a legkisebb mértékben sem lehetnek jogellenesek vagy sértők. Kérjük, a használat során:
(a) ne sértse meg más személyiségi jogait;
(b) ne sértsen meg semmilyen szellemi tulajdonhoz fűződő jogot;
(c) ne tegyen fel becsületsértő, pornográfiára utaló, rasszista vagy idegengyűlölő természetű, gyűlöletet keltő, erőszakra vagy rendzavarásra felbujtó tartalmakat.
(d) ne töltsön fel vírust tartalmazó vagy esetlegesen biztonsági problémákat eredményező fájlokat; és
(e) semmilyen egyéb módon ne veszélyeztesse a weboldal sértetlenségét.

Tájékoztatjuk, hogy az oldal készítője a jogellenesnek vagy sértőnek tartott tartalmakat a weboldalról eltávolíthatja.

Adatvédelem:
Az Adatvédelmi Irányelvek a weboldalon megosztott minden személyes adatra vagy anyagra kiterjed. Az adatvédelmi irányelveket itt találja.

Szellemi alkotásokhoz fűződő jogok
A weboldalon megjeleníteni kívánt anyagok (pl. szövegek vagy fotók) kizárólag a szellemi termékek jogos tulajdonosai engedélyével jelenhetnek meg! Az oldal készítője semmilyen felelősséget nem vállal az illegális tartalmak megjelenítésével kapcsolatban. A felelősség kizárólag az azt megosztó személyt terheli.
A Felhasználó jogosult a weboldal tartalmából készült kivonatokat magáncélra (azaz nem kereskedelmi felhasználás céljából) sokszorosítani. E jog gyakorlásának feltétele, hogy a Felhasználó érintetlenül hagyja és tekintetbe veszi a szellemi tulajdonhoz fűződő jogokat, köztük az egyes tartalmakhoz kapcsolódóan feltüntetett szerzői jogokra vonatkozó nyilatkozatot.

A Felhasználók által szolgáltatott tartalom
A Felhasználó kijelenti, hogy a weboldalra általa feltett tartalomnak a szerzője vagy rendelkezik a tartalomra vonatkozó jogokkal (azaz a jogosulttól engedélyt kapott a tartalom megosztására) és a tartalmat (pl. képek) weboldalon megoszthatja.

A Felhasználó belegyezik, hogy az általa feltöltött tartalom nem bizalmasan lesz kezelve, valamint hozzájárul ahhoz, hogy arra vonatkozóan jogdíjmentes, időbeli korlátozás nélkül, az egész világra kiterjedő felhasználási jogot nyújt a készítő számára (a tartalom közzétételére, sokszorosítására, továbbítására, nyilvánosságra hozására) kizárólagosan a weboldal működésével kapcsolatos célokból.

Tájékoztatjuk, hogy a programozó vagy az oldal működtetője saját belátása szerint dönthet a tartalom felhasználásáról, vagy esetleg annak a weboldalról történő eltávolításáról.

Felelősség:
A készítő mindent megtesz annak érdekében, hogy biztosítsák a weboldalon található anyagok pontosságát és elkerülje a zavarokat. Az NYEFamilyTree nem vállal felelősséget semmilyen pontatlan információból, zavarból, az oldal elérhetetlenségéből vagy egyéb eseményből eredő közvetlen (pl. számítógép meghibásodása) vagy közvetett (pl. elmaradt haszon) károkért. A Felhasználó vállalja, hogy a weboldalon található anyagokat kizárólag saját felelősségére használja.
A weboldal az NYEFamilyTree weboldalán kívüli weboldalakra mutató hivatkozásokat tartalmazhat. A készítőnek nincs ellenőrzése a harmadik felek weboldalai felett és nem feltétlenül támogatja azokat, illetve nem vállal felelősséget azokért, így azok tartalmáért, pontosságáért és működéséért. Így a legteljesebb mértékben arra bíztatjuk a Felhasználót, hogy ismerje meg és gondosan olvassa át a meglátogatott más weboldalakon elhelyezett jogi és adatvédelmi nyilatkozatokat, illetve ismerje azok esetleges módosításait.

Változások
Az NYEFamilyTree a jelen felhasználási feltételek módosításának jogát fenntartja. E felhasználási feltételek és az esetleges újabb információk áttekintése érdekében rendszeresen látogassa ezt az oldalt.

Irányadó jog és joghatóság
A weboldal kizárólag magyarországi felhasználók számára készült. A Felhasználó a weboldal látogatásával elfogadja, hogy a weboldal használatából származó vagy azzal kapcsolatos vitákra és követelésekre Magyarország joga alkalmazandó. Az esetleges jogviták eldöntésére Magyarország bíróságai rendelkeznek kizárólagos joghatósággal.
Felhasználó a weboldal látogatásával elfogadja a jelen Felhasználási feltételeket.
