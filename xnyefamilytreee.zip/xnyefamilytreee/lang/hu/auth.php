<?php

return [
    'failed' => 'Rossz email-jelszó páros.',
    'password' => 'A megadott jelszó helytelen.',
    'throttle' => 'Túl sok próbálkozás. Kérjük próbálja újra :seconds másodperc múlva.',
];