<?php

return [
    'next' => 'Következő &raquo;',
    'previous' => '&laquo; Előző',
];